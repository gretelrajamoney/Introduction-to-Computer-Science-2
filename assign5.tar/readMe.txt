Author: Gretel Rajamoney
Date: 3/15/2020
Program: Assignment 5

Description: I have designed a program which asks the user to input numbers,
the program prompts the user to continue inputting numbers until they would
like to stop inputting numbers. Using a linked list the program stores all 
of the numbers and uses nodes and pointers in order to access specific
indexes as well as to input numbers at certain locations. Next the program
asks the user whether they would like to sort the program in ascending or
descending order, based upon the users request, the number within the linked
list are sorted using the merge sort method. Next the program prints the
linked list in the user specified order and also prints out the total number
or prime numbers contained within the linked list. Lastly, to finish the 
program off, the program prompts the user asking whether they would like to 
run the program again or not. If the user says yes, the program runs again, 
and if the user says no, the program will exit out. 


