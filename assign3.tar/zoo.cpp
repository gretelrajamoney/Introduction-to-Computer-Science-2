/************************************************************
 *** Name: Gretel Rajamoney
 *** Date: 2/20/2020
 *** Program: zoo.cpp
 *** Description: creates all of the necessary functions and runs the game
 *** Input: zoo.h
 *** Output: game instructions and moves for the user
 ****************************************************************/



#include "zoo.h"
#include <iostream>
#include <cstdlib>
#include <ctime>


using namespace std;


//default constructor for zoo class, creates dynamic arrays for each animal andbegins by filling them with NULL, also gives the user 100,000$ in order to start the game
Zoo::Zoo()
{
	tigers = new Animal * [10];
	sealions = new Animal * [10];
	blackbears = new Animal * [10];

	tigersize = 10; 
	sealionsize = 10;
	blackbearsize = 10;
	
	int attendanceboom;
	money = 100000;
	attendanceboom = 0;

	for(int x = 0; x < 10; x++)
	{
		tigers[x] = NULL;
		sealions[x] = NULL;
		blackbears[x] = NULL;
	}
}

//defauls destructor for zoo class
Zoo::~Zoo(){}

//adds animal to the dynamic array of its type when called
void Zoo::addanimal(Animal *a)
{
	if(a -> gettype() == "tiger")
	{
		addtiger(a);
	}
	else if(a -> gettype() == "sealion")
	{
		addsealion(a);
	}
	else if(a -> gettype() == "blackbear")
	{
		addblackbear(a);
	}
}


//when called, adds a tiger to the dynamic array, and resizes the array
void Zoo::addtiger(Animal *a)
{
	if(isfull(tigers,tigersize))
	{
		rearrange(tigers,tigersize);
	}
	for(int x = 0; x < tigersize; x++)
	{
		if(tigers[x] == NULL)
		{
			tigers[x] = a;
			break;
		}
	}
}

//when called, adds a sealion to the dynamic array, and resizes the array
void Zoo::addsealion(Animal *a)
{
	if(isfull(sealions,sealionsize))
	{
		rearrange(sealions,sealionsize);
	}
	for(int x = 0; x < sealionsize; x++)
	{
		if(sealions[x] == NULL)
		{
			sealions[x] = a;
			break;
		}
	}
}

//when called, adds a blackbear to the dynamic array, and resizes the array
void Zoo::addblackbear(Animal *a)
{
	if(isfull(blackbears,blackbearsize))
	{
		rearrange(blackbears,blackbearsize);
	}
	for(int x = 0; x < blackbearsize; x++)
	{
		if(blackbears[x] == NULL)
		{
			blackbears[x] = a;
			break;
		}
	}
}

//when an animal is deleted, the array will delete dynamically to avoid memory leaks and will aslo call the specific animal delete function for its type
void Zoo::deletearrays()
{
	int z;
	z = 0;
	
	while(tigers[z] != NULL)
	{
		delete tigers[z];
		z++;
	}

	z = 0;
	
	while(sealions[z] != NULL)
	{
		delete sealions[z];
		z++;
	}
	
	z = 0;
	
	while(blackbears[z] != NULL)
	{
		delete blackbears[z];
		z++;
	}
		
	z = 0;

	delete [] tigers;
	delete [] sealions;
	delete [] blackbears;
}

//prints out the number of each animal type that are currently in the zoo
void Zoo::printanimals()
{
	cout << "animals currently in the zoo: " << endl;

	int n = 0;
	int tigeramount;
	int sealionamount;
	int blackbearamount;
	
	tigeramount = 0;
	sealionamount = 0;
	blackbearamount = 0;
	
	while(tigers[n] != NULL)
	{
		tigeramount++;
		n++;
	}
	
	n = 0;

	while(sealions[n] != NULL)
	{
		sealionamount++;
		n++;
	}
	
	n = 0;

	while(blackbears[n] != NULL)
	{
		blackbearamount++;
		n++;
	}

	cout << "tigers: " << tigeramount << endl;
	cout << "sealions: " << sealionamount << endl;
	cout << "blackbears: " << blackbearamount << endl;
}

//resizes the array dynamically whenever animals are deleted or added
void Zoo::rearrange(Animal **&a, int &size)
{
	Animal **newarray = new Animal *[size * 2];

	for(int x = 0; x < size * 2; x++)
	{
		newarray[x] = NULL;
	}
	for(int x = 0; x < size; x++)
	{
		newarray[x] = a[x];
	}

	delete [] a;

	a = newarray;

	size = size * 2;
}

//this functions checks whether the array needs resizing
bool Zoo::isfull(Animal **a, int size)
{
	for(int x = 0; x < size; x++)
	{
		if(!a[x])
		{
			return false;
		}
	}
	
	return true;
}

//returns the total amount of money in the users bank account
int Zoo::moneytotal()
{
	return money;
}

//subtracts costs from bank account whenever called
void Zoo::payment(int m)
{
	money = money - m;
}

//adds profits to bank account whenever called
void Zoo::paycheck(int m)
{
	money = money + m;
}

//allows user to purchase up to two tigers if they can afford it
void Zoo::buytiger()
{
	int buy;
	int amount;
	cout << "tigers cost $12,000 & you currently have $" << moneytotal() << endl;
	cout << "would you like to purchase any tigers? 1-yes 2-no" << endl;
	cin >> buy;

	if(buy == 1)
	{
	cout << "how many tigers would you like to buy?" << endl;
	cin >> amount;

	if(amount == 1)
	{
		payment(12000);
		cout << "you have just purchased a tiger!" << endl;
		cout << "your remaining balance is $" << moneytotal() << endl;
		addanimal(new Tiger());
	}
	else if(amount == 2)
	{
		payment(24000);
		cout << "you have just purchased two tigers!" << endl;
		cout << "your remaining balance is $" << moneytotal() << endl;
		addanimal(new Tiger());
		addanimal(new Tiger());
	}
	}
	

	cout << "_________________________________" << endl;
}

//allows user to purchase up to two sealions if they can afford it
void Zoo::buysealion()
{
	int buy;
	int amount;
	cout << "sealions cost $700 & you currently have $" << moneytotal() << endl;
	cout << "would you like to purchase any sealions? 1-yes 2-no" << endl;
	cin >> buy;	
	
	if(buy == 1)
	{
	cout << "how many sealions would you like to buy?" << endl;
	cin >> amount;

	if(amount == 1)
	{
		payment(700);
		cout << "you have just purchased a sealion!" << endl;
		cout << "your remaining balance is $" << moneytotal() << endl;
		addanimal(new Sealion());
	}
	else if(amount == 2)
	{
		payment(1400);
		cout << "you have just purchased two sealions!" << endl;
		cout << "your remaining balance is $" << moneytotal() << endl;
		addanimal(new Sealion());
		addanimal(new Sealion());
	}
	}
	cout << "___________________________________" << endl;
}

//allows user to purchase up to two blackbears if they can afford it
void Zoo::buyblackbear()
{
	int buy;
	int amount;
	cout << "blackbears cost $5,000 & you currently have $" << moneytotal() << endl;
	cout << "would you like to purchase any blackbears? 1-yes 2-no" << endl;
	cin >> buy;
	
	if(buy == 1)
	{	
	cout << "how many blackbears would you like to buy?" << endl;
	cin >> amount;

	if(amount == 1)
	{
		payment(5000);
		cout << "you have just purchased a blackbear!" << endl;
		cout << "your remaining balance is $" << moneytotal() << endl;
		addanimal(new Blackbear());
	}
	else if(amount == 2)
	{
		payment(10000);
		cout << "you have just purchased two blackbears!" << endl;
		cout << "your remaining balance is $" << moneytotal() << endl;
		addanimal(new Blackbear());
		addanimal(new Blackbear());
	}
	}
		cout << "____________________________________" << endl;
}

//function that ensures that the user purchases animals when they begin the game
void Zoo::buyanimals()
{
	buytiger();
	buysealion();
	buyblackbear();
}

//ages all of the animals by one month
void Zoo::ageanimals()
{
	int x = 0;

	while(tigers[x] != NULL)
	{
		tigers[x] -> raiseage();
		x++;
	}
	
	x = 0;

	while(sealions[x] != NULL)
	{
		sealions[x] -> raiseage();
		x++;
	}

	x = 0;

	while(blackbears[x] != NULL)
	{
		blackbears[x] -> raiseage();
		x++;
	}
}

//calculates the total feeding cost for each animal after getting the base cost
int Zoo::feedingcost()
{
	int x = 0;
	int totalcost = 0;
	
	while(tigers[x] != NULL)
	{
		totalcost += tigers[x] -> getbasecost();
		x++;
	}

	x = 0;
	
	while(sealions[x] != NULL)
	{
		totalcost += sealions[x] -> getbasecost();
		x++;
	}
	
	x = 0;

	while(blackbears[x] != NULL)
	{
		totalcost += blackbears[x] -> getbasecost();
		x++;
	}

	return totalcost;
}

//calculates the total revenue generated by each animal at the end of the month
int Zoo::calculatepay()
{
	int x = 0;
	int totalpay = 0;

	while(tigers[x] != NULL)
	{
		totalpay += tigers[x] -> getpay();
		x++;
	}
	
	x = 0;
	
	while(sealions[x] != NULL)
	{
		totalpay += sealions[x] -> getpay();
		x++;
	}
	
	x = 0;

	while(blackbears[x] != NULL)
	{
		totalpay += blackbears[x] -> getpay();
		x++;
	}
}

//removes tiger from the zoo using dynamically allocated arrays
void Zoo::tigerdies()
{
	int last;
	int x = 0;
	
	while(tigers[x] != NULL)
	{
		last = x;
		x++;
	}
	
	delete tigers[x-1];
	tigers[x-1] = NULL;
}

//removes sealion from the zoo using dynamically allocated arrays
void Zoo::sealiondies()
{
	int last;
	int x = 0;
	
	while(sealions[x] != NULL)
	{
		last = x;
		x++;
	}
	
	delete sealions[x-1];
	tigers[x-1] = NULL;
}

//removes blackbear from the zoo using dynamically allocated arrays
void Zoo::blackbeardies()
{
	int last;
	int x = 0;

	while(blackbears[x] != NULL)
	{
		last = x;
		x++;
	}
	
	delete blackbears[x-1];
	blackbears[x-1] = NULL;
}

//function that randomly selects an event for the month
void Zoo::event()
{
	int select = (rand() % 4 + 1);
	cout << "your randomly selected event is: ";

	switch (select)
	{
		case 1: cout << "an animal has gotten sick :(" << endl;
			sick();
			break;
		case 2: cout << "a boom in attendance!!" << endl;
			boom();
			break;
		case 3: cout << "a baby will be born!!" << endl;
			baby();
			break;
		case 4: cout << "nothing occured!!" << endl;
			break;
		default: cout << "error!!" << endl;
			break;
	}
}

//function for the sick event that randomly selects an animal to become sick
void Zoo::sick()
{
	int pick = (rand() % 3 + 1);
	
	switch (pick)
	{
		case 1:
			if(tigers[0] == NULL)
			{
				cout << "a tiger disease has spread within your zoo, but there are no tigers in your zoo" << endl;
				break;
			}
			else
			{
				cout << "unfortunately a tiger in your zoo has become sick :(" << endl;
				if(moneytotal() >= 6000)
				{
					payment(6000);
					cout << "the tiger has recovered at an expense of $6000" << endl;
					break;
				}
				else
				{
					tigerdies();
					cout << "your tiger has died :(" << endl;
					break;
				}
			}
			break;
		case 2:
			if(sealions[0] == NULL)
			{
				cout << "a sealion disease has spread within your zoo, but there are no sealions in your zoo" << endl;
				break;
			}
			else
			{
				cout << "unfortunately a sealion in your zoo has become sick :(" << endl;
				if(moneytotal() > 350)
				{
					payment(350);
					cout << "the sealion has been recovered at an expense of $350" << endl;
					break;
				}
				else
				{
					sealiondies();
					cout << "your sealion has died :(" << endl;
					break;
				}
			}
			break;
		case 3:
			if(blackbears[0] == NULL)
			{
				cout << "a blackbear disease has spread within your zoo, but there are no blackbears in your zoo" << endl;
				break;
			}
			else
			{
				cout << "unfortunately a blackbear in your zoo has become sick :(" << endl;
				if(moneytotal() > 2500)
				{
					payment(2500);
					cout << "the blackbear has been recovered at an expense of $2500" << endl;
					break;
				}
				else
				{
					blackbeardies();
					cout << "your blackbear has died :(" << endl;
					break;
				}
			}
			break;
		default: cout << "there was an error selecting a sick animal" << endl;
		break;
	}
}

//function for the attendance boom event which generates the extra revenue
void Zoo::boom()
{
	int x;
	x = 0;
	int numsealions;
	numsealions = 0;
	int randombonus;
	randombonus = 0;
	
	while(sealions[x] != NULL)
	{
		x++;
		numsealions = x;
	}
	if(numsealions != 0)
	{
		int pick;
		pick = (rand() % 250 + 1) + 250;
		randombonus = (numsealions) * pick;
		cout << "there was a boom in zoo attendance!" << endl;
		cout << "the sealions earned an extra $" << randombonus << endl;

		paycheck(randombonus);
		attendancebonus = randombonus;
	}
	else
	{
		cout << "you have no sealions :/" << endl;
	}
}

//randomly selects and animal to give birth and then adds the babies to the zoo using the dynamic array
void Zoo::baby()
{
	int pick = (rand() % 3 + 1);
	int x = 0;
	bool birth = false;
		
	switch(pick)
	{
		case 1:
			while(tigers[x] != NULL)
			{
				if(tigers[x] -> getage() >= 4)
				{
					cout << "three baby tigers were born :)" << endl;
					for(int i = 0; i < 3; i++)
					{
						addanimal(new Tiger(0));
					}
						birth = true;
						break;
				}
				x++;
			}

			if(!birth)
			{
				cout << "there are no tigers old enough to have children :/" << endl;
			}
			break;
		case 2:
			while(sealions[x] != NULL)
			{
				if(sealions[x] -> getage() >= 4)
				{

					cout << "a baby sealion was born :)" << endl;
					addanimal(new Sealion(0));
					birth = true;
					break;
				}
				x++;
			}
			cout << "there are no sealions old enough to have children :/" << endl;
			break;
		case 3:
			while(blackbears[x] != NULL)
			{
				if(blackbears[x] -> getage() >= 4)
				{
					cout << "two baby blackbears were born :)" << endl;
					
					for(int a = 0; a < 2; a++)
					{
						addanimal(new Blackbear(0));
					}
					birth = true;
					break;
				}
				x++;
			}
				if(!birth)
				{
					cout << "there are no blackbears old enough to have children :/" << endl;
				}
				break;
		default: cout << "there was an error selecting an animal" << endl;
			 break;
	}
}

//allows the user to purchase animals for the zoo
void Zoo::shop()
{
	int pick;
	
	cout << "would you like to buy any animals for your zoo? 1-yes 2-no" << endl;
	cin >> pick;
	
	if(pick == 1)
	{
		int species;
		cout << "what species would you like to buy? 1-tiger 2-sealion 3-blackbear" << endl;
		cin >> species;
		
		switch(species)
		{
			case 1:
				if(moneytotal() < 12000)
				{ 
					cout << "you dont have enough money to purchase a tiger :/" << endl;
				}
				else
				{
					addanimal(new Tiger(3));
					payment(12000);
					cout << "you have just purchased a tiger, you have $" << moneytotal() << " remaining in your bankaccount" << endl;
				} 
				break;
			case 2:
				if(moneytotal() < 700)
				{
					cout << "you dont have enough money to purchase a sealion :/" << endl;
				}
				else
				{
					addanimal(new Sealion(3));
					payment(700);
					cout << "you have just purchased a sealion, you have $" << moneytotal() << "remaining in your bankaccount" << endl;
				}
				break;
			case 3:
				if(moneytotal() < 5000)
				{
					cout << "you dont have enough money to purchase a blackbear :/" << endl;
				}
				else
				{
					addanimal(new Blackbear(3));
					payment(5000);
					cout << "you have just purchased a blackbear, you have $" << moneytotal() << "remaining in your bankaccount" << endl; 
				}
				break;
			default :
				cout << "sorry but that is not a valid input" << endl;
				break;
		}
	}
}

//starts the game for the user to play
void Zoo::play()
{	
	int pick;
	srand(time(NULL));

	cout << "would you like to enter zoo simulator? 1-yes 2-no" << endl;
	cin >> pick;
	
	if(pick == 2)
	{
		cout << "quitting zoo simulation" << endl;
		exit(0);
	}
	
	buyanimals();

	int month;
	month = 1;
	int foodcost;
	foodcost = 0;
	int profit;
	profit = 0;

	while(true)
	{
		cout << "_____________________________________" << endl;
		cout << "month: " << month << endl;
		
		attendancebonus = 0;
		profit = 0;
	
		printanimals();

		ageanimals();
		
		foodcost = feedingcost();			
		payment(foodcost);
		cout << "it costs $" << feedingcost() << " to feed all of your animals this month, you have $" << moneytotal() << " left in your bank account" << endl;

		cout << "your random event of the month is:" << endl;
		event();
		
		cout << "your summary for this month is:" << endl;
		cout << "the animals generated: $" << calculatepay() << endl;
		cout << "the feeding cost was: $" << feedingcost() << endl;
		
		if(attendancebonus != 0)
		{
			profit = ((calculatepay() - feedingcost()) + attendancebonus);
			cout << "the bonus from the attendance boom was: $" << profit << endl;
		}
		else
		{
			profit = ((calculatepay() - feedingcost()));
			cout << "the total profit for the month is: $" << profit << endl;
		}
		
		paycheck(profit);
		shop();
		
		month++;
	}
	deletearrays();
}
