/******************************************************************************************
 * Author : Gretel Rajamoney
 * Program : game.h
 * Date: 3/1/2020
 * Description : stores all of the functions and variables for running the game
 * Input : none
 * Output : none
 * ***************************************************************************************/

#ifndef GAME_H
#define GAME_H
#include <iostream>
#include <cstdlib>
#include <time.h>
#include "room.h"

using namespace std;



class Game : Room
	{
		protected:
			Room **rooms;
			int grid;
			int arrows;
			int collectedgold;
			int startx;
			int starty;
			int positionx;
			int positiony;
			int movechoice;
			char movement;
			bool over;
			bool win;
			bool restart;
			bool killedmonster;
			bool debug;
		public:
			Game();
			Game(bool);
			void setgrid();
			void makerooms();
			void move();
			int randomposition();
			void eventplacing();
			void startposition();
			void removearrows();
			char getmove();
			bool getwin();
			bool withingrid(int, int);

			~Game();

			void givehint();
			void firearrow();
			void movetype();
			void finish();
			void won();
			void run(int);
			void printgrid();
			void moveplayer();
			void checkevent();
			void getmovechoice();
	};

#endif
