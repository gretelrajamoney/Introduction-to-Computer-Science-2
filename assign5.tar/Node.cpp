/************************************************************
 * Program: Node.cpp
 * Date: 3/13/2020
 * Author: Gretel Rajamoney
 * Description: carries all of the necessary functions for the Node class
 * Input: no inputs
 * Output: no outputs
 * *********************************************************/

//imports necessary libraries to run the program
#include <iostream>
#include <string>

//imports the inherited classes
#include "Node.h"
#include "List.h"

using namespace std;

//constructor for the linked list node
LinkedListNode::LinkedListNode()
{
	value = 0;
	moveforward = NULL;
}

//destructor for the linked list node
LinkedListNode::~LinkedListNode()
{
	if(moveforward != NULL)
	{
		delete moveforward;
	}
}

/************************************************************
 * Function: mergeAscend()
 * Description: sorts all of the nodes within the linked list in
 * an ascending order through using conditional statements
 * Parameters: requires two head pointers for the linked list
 * Pre-Conditions: calls the necessary functions
 * Post-Conditions: both node head pointers are compared and then 
 * sorted using the merge formatting
 * *********************************************************/

LinkedListNode * mergeAscend(LinkedListNode * firstHead, LinkedListNode * secondHead)
{
	LinkedListNode * fakeHead1 = new LinkedListNode;
	LinkedListNode * fakeHead2 = new LinkedListNode;
	LinkedListNode * fakeHead3 = new LinkedListNode;

	if(firstHead == NULL)
	{
		return secondHead;
	}
	if(secondHead == NULL)
	{
		return firstHead;
	}

	fakeHead1 = firstHead;

	while(secondHead != NULL)
	{
		fakeHead2 = secondHead;
		secondHead = secondHead -> moveforward;
		fakeHead2 -> moveforward = NULL;

		if(firstHead -> value > fakeHead2 -> value)
		{
			fakeHead2 -> moveforward = firstHead;
			firstHead = fakeHead2;
			fakeHead1 = firstHead;
			continue;
		}
	

		//inserts a flag trip for the conditions within the if/else statement
		flag:

		if(fakeHead1 -> moveforward == NULL)
		{
			fakeHead1 -> moveforward = fakeHead2;
			fakeHead1 = fakeHead1 -> moveforward;
		}
		else if(fakeHead1 -> moveforward -> value <= fakeHead2 -> value)
		{
			fakeHead1 = fakeHead1 -> moveforward;
			goto flag;
		}
		else
		{
			fakeHead3 = fakeHead1 -> moveforward;
			fakeHead1 -> moveforward = fakeHead2;
			fakeHead2 -> moveforward = fakeHead3;
		}
	}
	
	return firstHead;
}

/*************************************************************
 * Function: mergeDescend()
 * Description: sorts all of the nodes within the linked list in
 * an descending order through using conditional statements
 * Parameters: requires two head pointers for the linked list
 * Pre-Conditions: calls the necessary functions
 * Post-Conditions: both node head pointers are compared and then
 * sorted using the merge formatting
 * **********************************************************/

LinkedListNode * mergeDescend(LinkedListNode * firstHead, LinkedListNode * secondHead)
{
	LinkedListNode * fakeHead1 = new LinkedListNode;
	LinkedListNode * fakeHead2 = new LinkedListNode;
	LinkedListNode * fakeHead3 = new LinkedListNode;

	if(firstHead == NULL)
	{
		return secondHead;
	}
	if(secondHead == NULL)
	{
		return firstHead;
	}

	fakeHead1 = firstHead;
	
	while(secondHead != NULL)
	{
		fakeHead2 = secondHead;
		secondHead = secondHead -> moveforward;
		fakeHead2 -> moveforward = NULL;
	
		if(firstHead -> value < fakeHead2 -> value)
		{
			fakeHead2 -> moveforward = firstHead;
			firstHead = fakeHead2;
			fakeHead1 = firstHead;
			continue;
		}
		
		flag:
	
		if(fakeHead1 -> moveforward == NULL)
		{
			fakeHead1 -> moveforward = fakeHead2;
			fakeHead1 = fakeHead1 -> moveforward;
		}
		else if(fakeHead1 -> moveforward -> value >= fakeHead2 -> value)
		{
			fakeHead1 = fakeHead1 -> moveforward;
			goto flag;
		}
		else
		{
			fakeHead3 = fakeHead1 -> moveforward;
			fakeHead1 -> moveforward = fakeHead2;
			fakeHead2 -> moveforward = fakeHead3;
		}
	}
		
	return firstHead;
}

/***********************************************************
 * Function: take()
 * Description: calls the function which asks for the numbers
 * Parameter: no parameters
 * Pre-Conditions: calls the necessary functions
 * Post-Conditions: the ordered linked list is printed
 * ********************************************************/

void take()
{
	LinkedList l2;
	
	string orderPick;
	
	orderPick = l2.takeNumber();
	
	if(orderPick == "a")
	{
		l2.ascendSort();
	}
	else
	{
		l2.descendSort();
	}

	l2.display();
	l2.isPrime();
	l2.empty();
}

/**********************************************************
 * Function: takeNumber()
 * Description: runs the required functions until the user wants to stop
 * Parameters: no parameters
 * Pre-Conditions: calls the necessary functions
 * Post-Conditions: the linked list gets printed to the screen 
 * repeatedly until the user wants to stop
 * *******************************************************/

void takeNumber()
{
	int run;
	run = 1;
	string userRepeat;

	while(run)
	{
		take();

		cout << "would you like to run this program again? y-yes n-no:";
		getline(cin, userRepeat); 
	
		if(userRepeat == "n")
		{
			run = 0;
		}
	}
}
