/****************************************************************
 * Author : Gretel Rajamoney
 * Program : pit.cpp
 * Date : 2/29/2020
 * Description: prints the hint for the pit event
 * Input : none
 * Output : hint
 * *************************************************************/



#include "pit.h"


Pit::Pit()
{
	hint = "*you feel a breeze*";
	symbol = 'p';
}

string Pit::gethint()
{
	return hint;
}

