/***************************************************************
 * Author : Gretel Rajamoney
 * Program : gold.h
 * Date : 2/29/2020
 * Description : carries the gold variables and functions
 * Input : none
 * Output : none
 * ************************************************************/

#ifndef GOLD_H
#define GOLD_H
#include "event.h"


class Gold : public Event
{
	protected:
		string hint;
	public:
		Gold();
		string gethint();
};

#endif
		
