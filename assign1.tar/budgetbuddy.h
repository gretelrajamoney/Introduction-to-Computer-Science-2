/*****************************************************************
 * Program: budgetbuddy.h
 * Name: Gretel Rajamoney
 * Description: contains all structs & function calls
 * Date: 01/19/2020
 * Input: none
 * Output: none
 * **************************************************************/

//imports libraries

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <string>

using namespace std;

//user struct

#ifndef User_H
#define User_H
struct user 
{
   string name;
   int id;
   string password;
};
#endif

//transaction struct

#ifndef Transaction_H
#define Transaction_H
struct transaction
{
   float amount;
   string date;
   string category;
   string description;
};
#endif

//budget struct

#ifndef Budget_H
#define Budget_H
struct budget
{
   int id;
   float balance;
   int num_transactions;
   struct transaction *t;
};
#endif

//calls all function

budget* create_budgets(int);
user* create_users(int);
void get_budget_data(budget*, int, ifstream &);
transaction* create_transactions(int);
void get_transaction_data(transaction*, int, ifstream &);
void delete_info(budget*, int);
