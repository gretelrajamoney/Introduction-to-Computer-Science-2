/****************************************************************
 * Author : Gretel Rajamoney
 * Program : pit.h
 * Date : 2/29/2020
 * Description : stores the pit variables and functions 
 * Input : none
 * Output : none
 * *************************************************************/

#ifndef PIT_H
#define PIT_H
#include "event.h"


class Pit : public Event
{
	protected:
		string hint;
	public:
		Pit();
		string gethint();
};

#endif
