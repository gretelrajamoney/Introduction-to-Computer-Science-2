/*********************************************************
 * Author : Gretel Rajamoney
 * Date : 2/29/2020
 * Program : hunt.cpp
 * Description : plays the hunt the wumpus game
 * Input : command lines for the grid size
 * Output : whether you won or lost the game
 * ******************************************************/

#include <iostream>
#include <stdlib.h>
#include "game.h"

using namespace std;


int main(int argc, char *argv[])
{
	if(argc < 3)
	{
		exit(1);
	}
	int boardsize = atoi(argv[1]);
	string arg2 = argv[2];
	bool debug;
	cout << "DEBUG: " << debug << endl;
	if(arg2 == "true")
	{
		debug = true;
	}
	else
	{
		debug = false;
	}
	Game test = Game(debug);
	
	if(boardsize < 4)
	{
		while(boardsize < 4)
		{
			cout << "you must enter a board size larger than 3, please try again: ";
			cin >> boardsize;	
		}
	}

	system("clear");
	cout << "welcome to hunt the wumpus !!!!" << endl;
	test.run(boardsize);

	return 0;
}

