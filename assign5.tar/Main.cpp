/************************************************************
 * Program: Main.cpp
 * Date: 3/13/2020
 * Author: Gretel Rajamoney
 * Description: this program runs the required functionality
 * in order to arrange numbers in ascending or descending order
 * Input: the inputted numbers for the linked lists, the inputted
 * yes or no selection, and the inputted order selection
 * Output: all of the prompts that require user inputs
 * *********************************************************/

//imports libraries necessary for the program
#include <iostream>
#include <string>

//imports classes to inherit from
#include "Node.h"
#include "List.h"

using namespace std;

/*************************************************************
 * Funtion: main()
 * Description: calls the function which requests the numbers
 * Parameters: no parameters
 * Pre-Conditions: command line contains 'run'
 * Post-Conditions: the program is then executed
 * **********************************************************/

int main()
{
	//calls the function which takes in the users inputs
	takeNumber();
	return 0;
}

