/*****************************************************************
 * Author : Gretel Rajamoney
 * Program : room.cpp
 * Date : 2/29/2020
 * Description : checks what is in each room and places events
 * Input : none
 * Output : none
 * **************************************************************/

#include "room.h"


Room::Room()
{
	event = ' ';
	inside = NULL;
	adventurer = 'x';
	srand(time(NULL));
}

char Room::findevent()
{
	return event;
}

char Room::getadventurer()
{
	return adventurer;
}

void Room::setevent(char event)
{
	this -> event = event;
	
	if(event == 'w')
	{
		inside = new Wumpus;
	}
	else if(event == 'g')
	{
		inside = new Gold;
	}
	else if(event == 'b')
	{
		inside = new Bat;
	}
	else if(event == 'p')
	{
		inside = new Pit;
	}
	else if(event == ' ')
	{
		inside = NULL;
	}
}

string Room::gethints()
{
	return inside -> gethint();
}

Room::~Room()
{
	delete[] inside;
}
