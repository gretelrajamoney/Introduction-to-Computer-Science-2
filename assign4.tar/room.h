/*****************************************************************
 * Author : Gretel Rajamoney
 * Program : room.h
 * Date : 2/29/2020
 * Description : carries all of the functions and variables that belong within each room and stores them within a Class
 * Input : none
 * Output : none
 * ***************************************************************/


#ifndef ROOM_H
#define ROOM_H
#include <iostream>
#include <cstdlib>
#include <time.h>
#include "bat.h"
#include "gold.h"
#include "wumpus.h"
#include "pit.h"

using namespace std;


class Room
{
	protected:
		Event *inside;
		char event;
		char adventurer;
	public:
		Room();

		char findevent();
		char getadventurer();
		string gethints();
		void setadventurer(char);
		void setevent(char);
		void setwumpus();

		~Room();
};

#endif
