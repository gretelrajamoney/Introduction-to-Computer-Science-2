/***************************************************************
 * Author : Gretel Rajamoney
 * Program : bat.h
 * Date : 2/29/2020
 * Description : carries all super bat variables and functions
 * Input : none
 * Output : none
 * *************************************************************/

#ifndef BAT_H
#define BAT_H
#include "event.h"
	

class Bat : public Event
{
	protected:
		string hint;
	public:
		Bat();
		string gethint();
		void printhint();
};

#endif
