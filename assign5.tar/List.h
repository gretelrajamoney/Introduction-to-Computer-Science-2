/************************************************************
 * Program: List.h
 * Date: 3/14/2020
 * Author: Gretel Rajamoney
 * Description: carries all variables and functions for the List.cpp class
 * Input: no inputs
 * Outputs: no outputs
 * *********************************************************/

#ifndef LIST_H
#define LIST_H

//imports all of the necessary libraries for the program
#include <iostream>
#include <string>

//inports necessary inheriting classes
#include "Node.h"

using namespace std;


class LinkedList
{
	private:
		unsigned int size;
		LinkedListNode * spotFirst;
		LinkedListNode * spotLast;
	public:
		LinkedList();
		~LinkedList();
		unsigned int getSize();
		void empty();
		void display();
		unsigned int goNext(int x);
		unsigned int putBack(int x);
		string takeNumber();
		unsigned int place(int value, unsigned int spot);
		void isPrime();
		void mergeSort(LinkedListNode **a, int choice);
		void ascendSort();
		void descendSort();
		unsigned int place(int, int);
};

#endif
