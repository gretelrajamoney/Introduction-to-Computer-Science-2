/**********************************************************
 * Author : Gretel Rajamoney
 * Program : event.cpp
 * Date : 2/29/2020
 * Description : prints out the events
 * Input : gets the hint
 * Output : the hint
 * *******************************************************/

#include "event.h"



Event::Event()
{
	hint = " ";
	symbol = ' ';
}

string Event::gethint()
{
	return hint;
}
	
void Event::printhint()
{
	cout << hint << endl;
}
