/************************************************************
 *** Name: Gretel Rajamoney
 *** Date: 2/20/2020
 *** Program: blackbear.h
 *** Description: creates the blackbear class
 *** Input: animal.h
 *** Output: none
 ***************************************************************/


#ifndef BLACKBEAR_H
#define BLACKBEAR_H
#include "animal.h"
#include <iostream>
#include <string>

using namespace std;

//creates blackbear class
class Blackbear : public Animal
{
	public:
		Blackbear();
		Blackbear(int);
};

#endif
