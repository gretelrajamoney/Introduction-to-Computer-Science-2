/******************************************************************
 * Author : Gretel Rajamoney
 * Program : game.cpp
 * Date : 2/29/2020
 * Description: carries all of the functions and variables to play the game
 * Input : command line arguments
 * Output : none
 * ****************************************************************/


#include "game.h"

//sets up all of the variables
Game::Game()
{
	grid = 0;
	movechoice = 0;
	collectedgold = 0;
	arrows = 3;
	startx = 0;
	starty = 0;
	positionx = 0;
	positiony = 0;
	movement = 'o';
	over = false;
	win = false;
	restart = false;
	killedmonster = false;
	srand(time(NULL));
	debug = false;
}

Game::Game(bool b){
	grid = 0;
	movechoice = 0;
	collectedgold = 0;
	arrows = 3;
	startx = 0;
	starty = 0;
	positionx = 0;
	positiony = 0;
	movement = 'o';
	over = false;
	win = false;
	restart = false;
	killedmonster = false;
	srand(time(NULL));
	cout << "B: " << b << endl;
	debug = b;
}

//gets the size of the gameboard
void Game::setgrid()
{
	cout << "pls enter your desired grid size: ";
	cin >> grid;
}

//makes an array of all of the rooms created
void Game::makerooms()
{
	rooms = new Room *[grid];

	for(int x = 0; x < grid; x++)
	{
		rooms[x] = new Room[grid];
	}
}

//asks where the player would like to move and stores it
void Game::move()
{
	cout << "w-up a-left d-right s-down" << endl;
	cin >> movement;
}

//generates a random number within the boardsize
int Game::randomposition()
{
	int place = rand() % (grid - 1);
	return place;
}

//randomly positions the events within the gameboard
void Game::eventplacing()
{
	rooms[startx][starty].setevent('x');
	int randx;
	int randy;
	while(true)
	{
		randx = randomposition();
		randy = randomposition();
		if(rooms[randx][randy].findevent() == ' ')
		{
			rooms[randx][randy].setevent('g');
			break;
		}
	}
	while(true)
	{
		randx = randomposition();
		randy = randomposition();
		if(rooms[randx][randy].findevent() == ' ')
		{
			rooms[randx][randy].setevent('w');
			break;
		}
	}
	while(true)
	{
		randx = randomposition();
		randy = randomposition();
		if(rooms[randx][randy].findevent() == ' ')
		{
			rooms[randx][randy].setevent('b');
			break;
		}
	}
	while(true)
	{
		randx = randomposition();
		randy = randomposition();
		if(rooms[randx][randy].findevent() == ' ')
		{
			rooms[randx][randy].setevent('b');
			break;
		}
	}
	while(true)
	{
		randx = randomposition();
		randy = randomposition();
		if(rooms[randx][randy].findevent() == ' ')
		{
			rooms[randx][randy].setevent('p');
			break;
		}
	}
	while(true)
	{
		randx = randomposition();
		randy = randomposition();
		if(rooms[randx][randy].findevent() == ' ')
		{
			rooms[randx][randy].setevent('p');
			break;
		}
	}

}

//generates the starting location for the player
void Game::startposition()
{
	positionx = startx = randomposition();
	positiony = starty = randomposition();

	cout << "adventurer start: " << startx << " " << starty << endl;
}

//removes arrow from count when one is fired
void Game::removearrows()
{
	if(arrows <= 0)
	{
		cout << "you have no more arrows :(" << endl;
		over = true;
	}
	else
	{
		arrows = arrows - 1;
	}
}

//returns the players move
char Game::getmove()
{
	return movement;
}

//returns status of the game (win or loss)	
bool Game::getwin()
{
	return win;
}

//prints out the grid to the player
void Game::printgrid()
{
	for(int x = 0; x < grid; x++)
	{
		for(int y = 0; y < grid; y++)
		{

			if(rooms[x][y].findevent() == 'x')
			{
				cout << "|" << "x" << "|";
			}
			else
			{
				if(debug == false)
				{
					cout << "| |";
				}
				else
				{
					cout << "|" << rooms[x][y].findevent() << "|";
				}
			}
		}
		cout << endl;
	}
}

//asks the player whether they would like to shoot an arrow or go through a tunnel
void Game::getmovechoice()
{
	cout << "would you like to move through a tunnel into a different room or would you like to fire an arrow? 1 or 2 : ";
	do{
		cin >> movechoice;
		if(cin.fail())
		{
			cin.clear();
			cin.ignore(100000, '\n');
			cout << "Invalid Input... please try again: ";
		}
		else if(movechoice < 1 || movechoice > 2)
		{
			cout << "Invalid Input... please try again: ";
		}
		else
		{
			break;
		}
	}while(true);

}

//changes the players location when they are moving
void Game::moveplayer()
{
	if((movement == 'w') && (withingrid(positionx - 1, positiony) == true))
	{
		rooms[positionx][positiony].setevent(' ');
		positionx--;
		checkevent();
		rooms[positionx][positiony].setevent('x');
	}
	else if((movement == 'a') && (withingrid(positionx, positiony - 1) == true))
	{
		rooms[positionx][positiony].setevent(' ');
		positiony--;
		checkevent();
		rooms[positionx][positiony].setevent('x');
	}

	else if((movement == 's') && (withingrid(positionx + 1, positiony) == true))
	{
		rooms[positionx][positiony].setevent(' ');
		positionx++;
		checkevent();
		rooms[positionx][positiony].setevent('x');
	}
	else if((movement == 'd') && (withingrid(positionx, positiony + 1) == true))
	{
		rooms[positionx][positiony].setevent(' ');
		positiony++;
		checkevent();
		rooms[positionx][positiony].setevent('x');
	}
	else
	{
		cout << "*you are out of bounds*" << endl;
	}
}

//checks if there is an event at their new location and acts upon it
void Game::checkevent()
{
	if(rooms[positionx][positiony].findevent() == 'w')
	{
		cout << "you have entered the room with the sleeping wumpus, he just woke up & ate you :(" << endl;
		over = true;
	}		
	else if(rooms[positionx][positiony].findevent() == 'g')
	{
		cout << "you have just found the gold :)" << endl;
		collectedgold = collectedgold + 1;
	}
	else if(rooms[positionx][positiony].findevent() == 'p')
	{
		cout << "you have just fallen into a bottomless pit & died :(" << endl;
		over = true;
	}
	else if(rooms[positionx][positiony].findevent() == 'b')
	{
		cout << "you have just been picked up by the super bats & been dropped off at a new location :/" << endl;
		rooms[positionx][positiony].setevent(' ');
		positionx = randomposition();
		positiony = randomposition();
		rooms[positionx][positiony].setevent('x');
	}
	else
	{
	}
}

//ensures that the player stays within the gameboard
bool Game::withingrid(int x, int y)
{
	if(x > grid - 1 || y > grid - 1 || x < 0 || y < 0)
	{
		return false;
	}
	else
	{
		return true;
	}
}

//prints out the hints for the nearby events surrounding their location
void Game::givehint()
{
	if((withingrid(positionx + 1, positiony) == true) && (rooms[positionx + 1][positiony].findevent() != ' '))
	{
		cout << rooms[positionx + 1][positiony].gethints() << endl;
	}
	if((withingrid(positionx, positiony + 1) == true) && (rooms[positionx][positiony + 1].findevent() != ' '))
	{
		cout << rooms[positionx][positiony + 1].gethints() << endl;
	}
	if((withingrid(positionx - 1, positiony) == true) && (rooms[positionx - 1][positiony].findevent() != ' '))
	{
		cout << rooms[positionx - 1][positiony].gethints() << endl;
	}
	if((withingrid(positionx, positiony - 1) == true) && (rooms[positionx][positiony - 1].findevent() != ' '))
	{
		cout << rooms[positionx][positiony - 1].gethints() << endl;
	}
}

//fires arrow that either hits the wumpus or goes through 3 rooms maximum
void Game::firearrow()
{
	move();
	int posx = positionx;
	int posy = positiony;
	cout << "*your arrow has been fired*" << endl;

	if(movement == 'w')
	{
		for(int x = 1; x < 4; x++)
		{
			posx = positionx-1;
			posy = positiony;

			if((withingrid(posx, posy) == true) && (rooms[posx][posy].findevent() == 'w')) 	
			{
				cout << "*you have successfully killed the wumpus*" << endl;
				killedmonster = true;
				rooms[posx][posy].setevent(' ');
				break;
			}
			else
			{
				cout << "*you did not strike the wumpus*" << endl;
			}
		}
	}

	else if(movement == 'd')
	{
		for(int x = 1; x < 4; x++)
		{
			posx = positionx;
			posy = positiony+1;

			if((withingrid(posx, posy) == true) && (rooms[posx][posy].findevent() == 'w'))
			{
				cout << "*you have successfully killed the wumpus*" << endl;
				killedmonster = true;
				rooms[posx][posy].setevent(' ');
				break;
			}
			else
			{
				cout << "*you did not strike the wumpus*" << endl;
			}
		}
	}

	else if(movement == 'a')
	{
		for(int x = 1; x < 4; x++)
		{
			posx = positionx;
			posy = positiony - 1;

			if((withingrid(posx, posy) == true) && (rooms[posx][posy].findevent() == 'w'))
			{
				cout << "*you have successfully killed the wumpus*" << endl;
				killedmonster = true;
				rooms[posx][posy].setevent(' ');
				break;	
			}
			else
			{
				cout << "*you did not strike the wumpus*" << endl;
			}
		}
	}

	else if(movement == 's')
	{
		for(int x = 1; x < 4; x++)
		{
			posx = positionx + 1;
			posy = positiony;

			if((withingrid(posx, posy) == true) && (rooms[posx][posy].findevent() == 'w'))
			{
				cout << "*you have successfully killed the wumpus*" << endl;
				killedmonster = true;
				rooms[posx][posy].setevent(' ');
				break;
			}
			else
			{
				cout << "*you did not strike the wumpus*" << endl;
			}
		}
	}
}

//reacts based upon whether the player chose to fire arrow or move through a tunnel
void Game::movetype()
{
	getmovechoice();

	if(movechoice == 1)
	{
		move();
		moveplayer();
		checkevent();
	}
	else if(movechoice == 2)
	{
		removearrows();
		firearrow();
	}
}

//deletes array and is a deconstructor
Game::~Game()
{
	for(int x = 0; x < grid; x++)
	{
		delete[] rooms[x];
	}
	delete[] rooms;
}

//checks whether the game is over and gives the player options to chose from
void Game::finish()
{
	int pick;

	if(win != true)
	{
		cout << "you lost :( would you like to... restart the game with the same cave setup, restart the game with a new cave setup, or quit the game? 1 or 2 or 3 : ";
	}
	else
	{
		cout << "you won! :) would you like to... restart the game with the same cave setup, restart the game with a new cave setup, or quit the game? 1 or 2 or 3 : ";

	}
	cin >> pick;

	if(pick == 1)
	{
		win = false;
		over = false;
		run(grid);
	}
	else if(pick == 2)
	{
		win = false;
		over = false;
		restart = true;
		run(grid);
	}
	else
	{
		cout << "Exiting Game..." << endl;
		exit(1);
	}
}

//checks if the player won the game
void Game::won()
{
	if(positionx == startx && positiony == starty && collectedgold == 1 && killedmonster == true)
	{
		win = true;
		over = true;
	}
}

//runs the entire game by calling the functions
void Game::run(int size)
{
	grid = size;
	if(restart == true)
	{	
		setgrid();
	}

	makerooms();
	startposition();
	eventplacing();			
	printgrid();

	do{
		cout << endl;
		cout << "gold found : " << collectedgold << endl;
		cout << "arrows remaining : " << arrows << endl;
		cout << "location : " << positionx << " " << positiony << endl;

		givehint();
		movetype();
		printgrid();
		won();
	} while(over != true);
	finish();
}					

