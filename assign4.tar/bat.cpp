/*****************************************************
 * Author : Gretel Rajamoney
 * Program : bat.cpp
 * Date : 2/29/2020
 * Description : holds information relating to the super bats
 * Input : none
 * Output : super bats hint
 * **************************************************/

#include "bat.h"


Bat::Bat()
{
	hint = "*you hear wings flapping*";
	symbol = 'b';
}

string Bat::gethint()
{
	return hint;
}

void Bat::printhint()
{
	cout << hint << endl;
}
