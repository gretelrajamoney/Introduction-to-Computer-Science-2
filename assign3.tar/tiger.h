/************************************************************
 ** Name: Gretel Rajamoney
 ** Date: 2/20/2020
 ** Program: tiger.h
 ** Description: creates the tiger class
 ** Input: animal.h
 ** Output: none
 **************************************************************/


#ifndef TIGER_H
#define TIGER_H
#include "animal.h"
#include <string>
#include <iostream>

using namespace std;

//creates tiger class
class Tiger : public Animal 
{
	public:
		Tiger();
		Tiger(int);
};

#endif
