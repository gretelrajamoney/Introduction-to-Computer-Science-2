/************************************************************************
 * Author : Gretel Rajamoney
 * Program : wumpus.cpp
 * Date : 2/29/2020
 * Description : prints out the wumpus hint and symbol
 * Input : none
 * Output : none
 * *********************************************************************/

#include "wumpus.h"


Wumpus::Wumpus()
{
	hint = "*you smell a terrible stench*";
	alive = true;
	symbol = 'w';
}

string Wumpus::gethint()
{
	return hint;
}

bool Wumpus::monsteralive()
{
	return alive;
}

