/************************************************************
 *** Name: Gretel Rajamoney
 *** Date: 2/20/2020
 *** Program: zoo.h
 *** Description: creates the variables and functions and stores them in the zoo class
 *** Input: animal.h tiger.h sealion.h blackbear.h
 *** Output: none
 ***************************************************************/



#ifndef ZOO_H
#define ZOO_H

#include "animal.h"
#include "tiger.h"
#include "sealion.h"
#include "blackbear.h"
#include <iostream>
#include <string>

using namespace std;


class Zoo
{
	private:
		Animal **tigers;
		Animal **sealions;
		Animal **blackbears;
		
		int tigersize;
		int sealionsize;
		int blackbearsize;
		int money;
		int attendancebonus;
	
	public:
		Zoo();
		~Zoo();
		
		void addanimal(Animal *);
		void addtiger(Animal *);
		void addsealion(Animal *);
		void addblackbear(Animal *);
		void deletearrays();
		void printanimals();
		bool isfull(Animal **, int);
		void rearrange(Animal **&, int&);
		void play();
		int moneytotal();
		void payment(int);
		void paycheck(int);
		void buyanimals();
		void buytiger();
		void buysealion();
		void buyblackbear();
		void ageanimals();
		int feedingcost();
		void event();
		void sick();
		void boom();
		void baby();
		void tigerdies();
		void sealiondies();
		void blackbeardies();
		void shop();
		int calculatepay();
};

#endif	
