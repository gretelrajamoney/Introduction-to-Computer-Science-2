/************************************************************
 ** Name: Gretel Rajamoney
 ** Date: 2/20/2020
 ** Program: tiger.cpp
 ** Description: stores the appropriate tiger values into the animal variables
 ** Input: tiger.h
 ** Output: none 
 **************************************************************/



#include <string>
#include <iostream>
#include "tiger.h"

using namespace std;

//default constructor for constructor class
Tiger::Tiger() : Animal()
{
	cost = 12000;
	basecost = 80;
	foodcost = basecost * 5;
	pay = cost * 0.10;
	babies = 3;
	type = "tiger";
}

//constructor for tiger class
Tiger::Tiger(int a) : Animal()
{
	cost = 12000;
	basecost = 80;
	foodcost = basecost * 5;
	pay = cost * 0.10;
	babies = 3;
	type = "tiger";
	age = 0;
}
