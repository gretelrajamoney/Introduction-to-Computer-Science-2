/************************************************************
 *** Name: Gretel Rajamoney
 *** Date: 2/20/2020
 *** Program: sealion.h
 *** Description: creates the sealion class
 *** Input: animal.h
 *** Output: none
 ***************************************************************/



#ifndef SEALION_H
#define SEALION_H
#include "animal.h"
#include <iostream>
#include <string>

using namespace std;

//creates sealion class
class Sealion : public Animal
{
	public:
		Sealion();
		Sealion(int);
};

#endif
