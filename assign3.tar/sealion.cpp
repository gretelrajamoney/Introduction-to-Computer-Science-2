/************************************************************
 *** Name: Gretel Rajamoney
 *** Date: 2/20/2020
 *** Program: sealion.cpp
 *** Description: stores the appropriate sealion values into the animal variables
 *** Input: sealion.h
 *** Output: none
 ***************************************************************/



#include "sealion.h"
#include <iostream>
#include <string>

using namespace std;

//sealion default constructor
Sealion::Sealion() : Animal()
{
	cost = 700;
	basecost = 80;
	foodcost = basecost;
	babies = 1;
	pay = cost * 0.20;
	type = "sealion";
}

//sealion constructor
Sealion::Sealion(int a) : Animal()
{
	cost = 700;
	basecost = 80;
	foodcost = basecost;
	babies = 1;
	pay = cost * 0.20;
	type = "sealion";
	age = 0;
}
