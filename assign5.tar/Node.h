/************************************************************
 * Program: Node.h
 * Date: 3/13/2020
 * Author: Gretel Rajamoney
 * Description: carries all of the functions and variables
 * created and implemented in the Node.cpp class
 * Input: no inputs
 * Output: no outputs
 * *********************************************************/

#ifndef NODE_H
#define NODE_H

//imports the necessary functions for the program
#include <iostream>
#include <string>

using namespace std;

//mandatory "linked list node" class
class LinkedListNode
{
	public:
		int value;
		LinkedListNode * moveforward;
		LinkedListNode();
		~LinkedListNode();
};

//merging the necessary functions publicly for access throughout files
LinkedListNode * mergeAscend(LinkedListNode * firstHead, LinkedListNode * secondHead);
LinkedListNode * mergeDescend(LinkedListNode * firstHead, LinkedListNode * secondHead);

//function that requests input from user
void takeNumber();

#endif
