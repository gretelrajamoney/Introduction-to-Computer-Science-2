/************************************************************
 ** Name: Gretel Rajamoney
 ** Date: 2/20/2020
 ** Program: animal.h
 ** Description: creates animal class and stores variables in private and public
 ** Input: none
 ** Output: none
 **************************************************************/



#ifndef ANIMAL_H
#define ANIMAL_H

#include <string>
#include <iostream>

using namespace std;

//creates the animal class
class Animal
{
	protected:
		int age;
		int cost;
		int babies;
		int basecost;
		int foodcost;
		int pay;
		string type;

	public:
		Animal();
		Animal(int);
		~Animal();
		string gettype();
		int getage();
		int getcost();
		int getbasecost();
		int getpay();
		int getbabies();
		void raiseage();
};

#endif
