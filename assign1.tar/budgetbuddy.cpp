/**************************************************************************
 * Program: budgetbuddy.cpp
 * Name: Gretel Rajamoney
 * Date: 01/19/2020
 * Description: This is my implementation file for my Budget Buddy project, this file contains all of my functions.
 * Input: none, all void functions
 * Output: none, all void functions
 * ************************************************************************/

//importing all of my libraries
#include <iostream>
#include <cstring>
#include <stdlib.h>
#include <cstdio>
#include <fstream>
#include <string>
#include <array>
#include "budgetbuddy.h"

using namespace std;

/***************************************************************************
 * Function: create_budgets()
 * Description: creates an array to carry information from the budget structs
 * Inputs: int x
 * Outputs: budget* array
 * ************************************************************************/

budget* create_budgets(int x)
{
	budget* bud = new budget[x];
	return bud;
}

/**************************************************************************
 * Function: get_budget_data()
 * Description: gets the users budget and stores it
 * Inputs: budget* budgets, int x, ifstream & budgetdata
 * Outputs: void
 * ***********************************************************************/

void get_budget_data(budget* budgets, int x, ifstream & budgetdata)
{
	string line;
	string userline;
	int point;
	int flag = 0;
	int count = 0;
	getline(budgetdata, line);
	flag = flag + 1;
	for(int a = 0; a < x; a++) 
	{	
		getline(budgetdata, line);
		flag = flag + 1;
		userline = line.substr(0,8);
		budgets[a].id = stoi(userline);
		point = 9;
		while(true)
		{
			if(line[point] == ' ')
			{
			break;
			}
			else
			{
				point = point + 1;
			}		
			
		}
		userline = line.substr(9, point);
		budgets[a].balance = stof(userline);
		userline = line.substr(point + 1, 100000000);
		budgets[a].num_transactions = stoi(userline);
		transaction* transactions = create_transactions(budgets[a].num_transactions);
		int combo = (10*flag) + (budgets[a].num_transactions);
		get_transaction_data(transactions, combo, budgetdata);
		budgets[a].t = transactions;
	
	}

}

/********************************************************************************
 * Function: create_transactions()
 * Description: creates an array to carry information from the transaction structs
 * Input: int x
 * Output: transaction* array
 * *****************************************************************************/

transaction* create_transactions(int x)
{
	transaction* transactions = new transaction[x];
	return transactions;
}

/********************************************************************************
 * Function: get_transaction_data()
 * Description: gets the users transactions and stores it
 * Input: transaction* transactions, int x, ifstream & budgetdata
 * Output: void
 * *****************************************************************************/

void get_transaction_data(transaction* transactions, int x, ifstream & budgetdata)
{
	int flag = x/10;
	int numoftrans = x%10;
	string line;
	string userline;
	int point;
	int point2;
	for(int b = 0; b < numoftrans; b++)
		{
		point = 11;
		point2 = 0;
		string userline;

		getline(budgetdata, line);
		
		userline = line.substr(0,10);
		transactions[b].date = userline;
		while(true)
		{
			if(line[point] == ' ')
			{
				break;
			}
			else
			{
				point = point + 1;
			}
		}
		

		userline = line.substr(11, point);
		transactions[b].amount = stof(userline);
		point2 = point + 1;
		while(true)
		{
			if(line[point2] == ' ')
			{
				break;
			}
			else
			{
				point2 = point2 + 1;
			}
		}	
		userline = line.substr(point + 1, point2 - point - 1);
		transactions[b].description = userline;
		userline = line.substr(point2 + 1, 100000000);
		transactions[b].category = userline;	
	}
}

/***********************************************************************
 * Function: delete_info()
 * Description: deletes memory from the heap
 * Input: budget* budgetinfo, int y
 * Ouput: void
 * ********************************************************************/

void delete_info(budget* budgetinfo, int y)
{
	for(int i = 0; i < y; i++)
	{
		delete [] budgetinfo[i].t;
	}
	
	delete [] budgetinfo;
}



