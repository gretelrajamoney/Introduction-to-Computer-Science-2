/************************************************************
 * Program: List.cpp
 * Date: 3/14/2020
 * Author: Gretel Rajamoney
 * Description: lists all of the functions and variables for the List.cpp class
 * Input: no inputs
 * Output: no outputs
 * *********************************************************/

//imports all of the necessary libraries to run the program
#include <iostream>
#include <cstdlib>
#include <string>

//imports the classes necessary to inherit
#include "List.h"
#include "Node.h"

using namespace std;

//constructor for the LinkedList class
LinkedList::LinkedList()
{
	spotFirst = NULL;
	spotLast = NULL;
	size = 0;
}

//destructor for the LinkedList class
//also responsible for freeing up memory
LinkedList::~LinkedList()
{
	for(int x = 0; x < size; x++)
	{
		LinkedListNode * fakeHead3;
		fakeHead3 = spotFirst;
		spotFirst = spotFirst -> moveforward;
		delete fakeHead3;
	}

	this -> size = 0;
}

/************************************************************
 * Function: empty()
 * Description: frees all memory contained in the linked list
 * Parameters: no parameters
 * Pre-Conditions: function is called making the list not necessary
 * Post-Conditions: linked list is empties and all memory has been freed
 * *********************************************************/

void LinkedList::empty()
{
	for(int x = 0; x < this -> size; x++)
	{
		LinkedListNode * fakeHead3;
		fakeHead3 = spotFirst;
		spotFirst = spotFirst -> moveforward;
		delete fakeHead3;
	}

	this -> size = 0;
}

/************************************************************
 * Function: place()
 * Description: places the value at the specified index in the list
 * Parameters: specified int value of the specified index
 * Pre-Conditions: calls the place() function
 * Post-Conditions: the value is placed at the requested index
 * *********************************************************/

unsigned int LinkedList::place(int value, int spot)
{
	LinkedListNode * newNode = new LinkedListNode;
	LinkedListNode * begin = new LinkedListNode;
	LinkedListNode * end = new LinkedListNode;
	newNode -> value = value;
	int location;
	location = 0;
	end = spotFirst;
	
	if(spotFirst != NULL)
	{
		while(end -> moveforward != NULL)
		{
			begin = end;
			end = end -> moveforward;
			location++;
		}
		if(location == 0)
		{
			goNext(value);
		}
		else if(spot > location + 1)
		{
		
		}
		else
		{
			begin -> moveforward = newNode;
			newNode -> moveforward = end;
		}
	}
	else
	{
		spotFirst = newNode;
		newNode -> moveforward = NULL;
	}

	this -> size++;
	return this -> size;
}

/*************************************************************
 * Function:goNext()
 * Description: places the value inputted by the user into the
 * front of the list, moving all existing nodes forward
 * Parameters: the value waiting to be added into the list
 * Pre-Conditions: the putFront() function is called
 * Post-Conditions: the value is inserted into the front of the list
 * **********************************************************/

unsigned int LinkedList::goNext(int x)
{
	LinkedListNode * fakeHead3 = new LinkedListNode;
	fakeHead3 -> value = x;
	fakeHead3 -> moveforward = spotFirst;
	spotFirst = fakeHead3;

	this -> size++;
	return this -> size;
}

/**************************************************************
 * Function: putBack()
 * Description: places the value inputted by the user into the back
 * Parameters: the value waiting to be added into the list
 * Pre-Conditions: the putBack() function is called
 * Post-Conditions: the value is inserted into the back of the list
 * ***********************************************************/

unsigned int LinkedList::putBack(int x)
{
	LinkedListNode * fakeHead3 = new LinkedListNode;
	fakeHead3 -> value = x;
	fakeHead3 -> moveforward = NULL;

	if(spotFirst == NULL)
	{
		spotFirst = fakeHead3;
		spotLast = fakeHead3;
		fakeHead3 = NULL;
	}
	else
	{
		spotLast -> moveforward = fakeHead3;
		spotLast = fakeHead3;
	}
	
	this -> size++;
	return this -> size;
}

/************************************************************
 * Function: display()
 * Description: displays the linked list to the user
 * Parameters: no parameters
 * Pre-Conditions: the display() function is called
 * Post-Conditions: the linked list is displayed to the user
 * *********************************************************/

void LinkedList::display()
{
	LinkedListNode * fake = new LinkedListNode;
	fake = spotFirst;

	cout << "this is your linked list: ";
	
	while(fake != NULL)
	{
		cout << fake -> value << " ";
		fake = fake -> moveforward;
	}
	
	cout << endl;
}

/***********************************************************
 * Function: takeNumber()
 * Description: gets values from the user to add into the linked list
 * Parameters: no parameters
 * Pre-Conditions: the takeNumber() function is called in the main
 * Post-Conditions: the user continues to input values until finished
 * ********************************************************/

string LinkedList::takeNumber()
{
	int x;
	int run;
	string orderPick;
	string userRepeat;
	x = 1;
	run = 1;

	cout << "please enter a number: ";
	cin >> x;
	goNext(x);

	while(run)
	{
		cin.ignore();
		cout << "would you like to enter another number? y-yes n-no: ";
		getline(cin, orderPick);
	
		if(orderPick == "n")
		{
			run = 0;
		}
		else
		{
			int n;
			n = 0;
			cout << "please enter your number: ";
			cin >> n;
			goNext(x);
		}
	
	}

	cout << "would you like your list sorted in ascending or descending order? a-ascending d-descending: ";
	getline(cin, userRepeat);
	return userRepeat;
}

/************************************************************
 * Function: checkPrime()
 * Description: checks and returns if the inputted value is a prime
 * Parameters: the references to the nodes
 * Pre-Conditions: the checkPrime() function is called
 * Post-Conditions: a boolean for is the number is prime or not is returned
 * *********************************************************/

bool checkPrime(LinkedListNode & x)
{
	for(int a = 2; a < x.value; a++)
	{
		if(x.value < 0)
		{
			return false;
		}
		else if(x.value % a == 0)
		{
			return false;
		}
		else if(x.value == 1 || x.value == 0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	return false;
}

/***********************************************************
 * Function: mergeSort()
 * Description: breaks up the linked list in order to be sorted
 * Parameters: the node head pointer for merging either in ascending or descending order
 * Pre-Conditions: the mergeSort() function is called
 * Post-Conditions: the linked list is sorted either descending or ascending order
 * ********************************************************/

void LinkedList::mergeSort(LinkedListNode **x, int choice)
{
	LinkedListNode * spotOne = new LinkedListNode;
	LinkedListNode * spotTwo = new LinkedListNode;
	LinkedListNode * fakeHead3 = new LinkedListNode;
	
	spotOne = *x;
	fakeHead3 = *x;

	if(spotOne == NULL || spotOne -> moveforward == NULL)
	{
		return;
	}
	else
	{
		while(spotOne -> moveforward != NULL)
		{
			spotOne = spotOne -> moveforward;
			
			if(spotOne -> moveforward != NULL)
			{
				fakeHead3 = fakeHead3 -> moveforward;
				spotOne = spotOne -> moveforward;
			}
		}

		spotTwo = fakeHead3 -> moveforward;
		fakeHead3 -> moveforward = NULL;
		spotOne = *x;
	}

	mergeSort(&spotOne, choice);
	mergeSort(&spotTwo, choice);

	switch(choice)
	{
		case 1:
			*x = mergeAscend(spotOne, spotTwo);
			break;
		case 2:
			*x = mergeDescend(spotOne, spotTwo);
			break;
	}
}

/**********************************************************
 * Function: ascendSort()
 * Description: calls the mergeSort() function and sorts ascendingly
 * Parameters: no parameters
 * Pre-Conditions: the ascendSort() function is called
 * Post-Conditions: the linked list is sorted in ascending order
 * ********************************************************/

void LinkedList::ascendSort()
{
	mergeSort(&spotFirst, 1);
}

/**********************************************************
 * Function: descendSort()
 * Description: calls the mergeSort() function and sorts descendingly
 * Parameters: no parameters
 * Pre-Conditions: the descendSort() function is called
 * Post-Conditions: the linked list is sorted in descending order
 * *******************************************************/

void LinkedList::descendSort()
{
	mergeSort(&spotFirst, 2);
}

/**********************************************************
 * Function: isPrime()
 * Description: counts how many prime numbers are in the linked list
 * Parameters: no parameters
 * Pre-Conditions: the isPrime() function is called
 * Post-Conditions: the total number of prime numbers is printed
 * ********************************************************/

void LinkedList::isPrime()
{
	int count;
	count = 0;
	
	LinkedListNode * fakeHead3 = new LinkedListNode;
	fakeHead3 = spotFirst;

	for(int x = 0; x < size; x++)
	{
		if(checkPrime(*fakeHead3))
		{
			count++;
		}
	
		fakeHead3 = fakeHead3 -> moveforward;
	}
	
	cout << "your linked list contains " << count << " prime numbers!" << endl;
}

/**************************************************************
 * Function: getSize()
 * Description: returns the length of the list
 * Parameters: no parameters
 * Pre-Conditions: the getSize() function is called
 * Post-Conditions: the length of the list is returned
 * ***********************************************************/

unsigned int LinkedList::getSize()
{
	return this -> size;
}

