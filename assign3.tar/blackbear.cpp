/************************************************************
 *** Name: Gretel Rajamoney
 *** Date: 2/20/2020
 *** Program: blackbear.cpp
 *** Description: stores the appropriate blackbear values into the animal variables
 *** Input: blackbear.h
 *** Output: none
 ***************************************************************/

#include "blackbear.h"
#include <iostream>
#include <string>


using namespace std;

//default constructor for blackbear class
Blackbear::Blackbear() : Animal()
{
	cost = 5000;
	babies = 2;
	basecost = 80;
	foodcost = basecost * 5;
	pay = cost * 0.10;
	type = "blackbear";
}

//constructor for blackbear class
Blackbear::Blackbear(int a) : Animal()
{
	cost = 5000;
	babies = 2;
	basecost = 80;
	foodcost = basecost * 5;
	pay = cost * 0.10;
	type = "blackbear";
	age = 0;
}
