/************************************************************************
 * Author : Gretel Rajamoney
 * Program : wumpus.h
 * Date : 2/29/2020
 * Description : stores the variables is functions for the wumpus
 * Input : none
 * Output : none
 * *********************************************************************/

#ifndef WUMPUS_H
#define WUMPUS_H
#include "event.h"


class Wumpus : public Event
{
	protected:
		string hint;
		bool alive;
	public:
		Wumpus();
		string gethint();
		bool monsteralive();
};

#endif 
