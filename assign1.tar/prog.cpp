/********************************************************
 * Program: prog.cpp
 * Name: Gretel Rajamoney
 * Date: 01/19/2020
 * Description: driver file that contains the main function
 * Input: user id, password, selections
 * Output: user id, name, account balance, sorted transactions
 * ******************************************************/

//imports libraries

#include <iostream>
#include <cstring>
#include <string>
#include <stdlib.h>
#include <cstdlib>
#include <fstream>
#include "budgetbuddy.h"


using namespace std;

/***********************************************************
 * Function: int main()
 * Description: creates the command line arguements
 * Input: file names, user id, password
 * Output: error statements, displays log in screen
 * *******************************************************/

int main(int argc,char* argv[])
{
	if(argc > 3 || argc < 3)
	{
		cout << "ERROR!! File names do not exist, please try again." << endl;
		return 0;
	}

	string users = argv[1];
	string budgets = argv[2];
	string line;
	string inputID;	
	int userID;
	int tag;
	bool pass;	

	ifstream userfile;
	ifstream budgetfile;
	userfile.open(users);
	budgetfile.open(budgets);

	int numusers;

	getline(userfile, line);
	numusers = line[0]-48;


	cout << "Please enter your User ID: ";
	getline(cin, inputID);	
	userID = stoi(inputID);

	for(int a = 0; a < numusers; a++)
	{
		pass = false;
		getline(userfile, line);
		tag = 0;
		while(true)
		{
			if(line[tag] == ' ')
			{
				break;
			}
			else
			{
				tag++;
			}
		}
		if(stoi(line.substr(tag + 1,8)) == userID)
		{
			pass = true;
			break;
		}	
	}

	if(pass == false)
	{	
		cout << "Your User ID is incorrect!! Program exiting now!!" << endl;
		return 0;
	}

	user person;
	person.id = userID;
	person.name = line.substr(0,tag);
	person.password = line.substr(tag + 10, 100000000);	
	int strikes = 0;
	string inputpassword;

	while(strikes < 3)
	{
		cout << "Enter your password: ";
		getline(cin, inputpassword);
	
		if(inputpassword == person.password)
		{
			cout << "Logging In !!" << endl;
			break;
		}
		else if(strikes < 2)
		{
			strikes = strikes + 1;
			cout << "Your Password is incorrect! ";
		}
		else
		{
			cout << "That is incorrect, exiting program now!" << endl;
			return 0;
		}
	}
	

	budget* budge = create_budgets(numusers);
	get_budget_data(budge,numusers,budgetfile);
	int userlocation;
	
	for(int a = 0; a < numusers; a++)
	{
		if(person.id == budge[a].id)
		{
			userlocation = a;
			break;
		}
	}	

	cout << "Welcome " << person.name << "\n" << person.id << "\n" << "Account Balance: $" << budge[userlocation].balance << endl;

	int choice;

	cout << "Would you like to sort your transactions?" << endl;
	cout << "1. By Category" << endl;
	cout << "2. By Date" << endl;
	cout << "3. By Expense" << endl;
	cout << "4. Quit the Program" << endl;
	cout << "What would you like to do? :";
	
	cin >> choice;

	transaction* newtransaction = create_transactions(budge[userlocation].num_transactions);

	

	if(choice == 1)
	{
		for(int a = 0; a < budge[userlocation].num_transactions; a++)
		{
			int type = 0;
			
			for(int b = 1; b < budge[userlocation].num_transactions; b++)
			{
				if(budge[userlocation].t[b].category.compare(budge[userlocation].t[type].category) < 0)
				{
					type = b;
				}
			}
		newtransaction[a] = budge[userlocation].t[type];
		budge[userlocation].t[type].category = "ZZZZZZZ";
		}
	}

	if(choice == 2)
	{
		for(int a = 0; a < budge[userlocation].num_transactions; a++)
		{
			int day = 0;
			
			for(int b = 1; b < budge[userlocation].num_transactions; b++)
			{
				if(budge[userlocation].t[b].date.compare(budge[userlocation].t[day].date) < 0)
				{
					day = b;
				}
			}
		newtransaction[a] = budge[userlocation].t[day];
		budge[userlocation].t[day].date = "ZZZZZZZ";
		}
	}

	if(choice == 3)
	{
		for(int a = 0; a < budge[userlocation].num_transactions; a++)
		{
			int expense = 0;
			
			for(int b = 1; b < budge[userlocation].num_transactions; b++)
			{
				if(budge[userlocation].t[b].amount > budge[userlocation].t[expense].amount)
				{
				expense = b;
				}	
			}
		newtransaction[a] = budge[userlocation].t[expense];
		budge[userlocation].t[expense].amount = -1;
		}
	}
	
	if(choice != 1 && choice != 2 && choice != 3)
	{
		return 0;
	}


	
	int display;
	
	cout << "How would you like to display your transactions?" << endl;
	cout << "1. Print to a Separate File" << endl;
	cout << "2. Print to the Screen" << endl;
	cout << "What would you like to do? :";

	cin >> display;

	if(display == 1)
	{
		string file;
		cout << "What would you like to name your file? : ";
		cin >> file;
		ofstream filename;
		filename.open(file);
	
		for(int a = 0; a < budge[userlocation].num_transactions; a++)
		{
			filename << newtransaction[a].date << " $" << newtransaction[a].amount << " " << newtransaction[a].description << " " << newtransaction[a].category << endl;
		}
		filename.close();
	}			
		
	if(display == 2)
	{
		for(int a = 0; a < budge[userlocation].num_transactions; a++)
		{
			cout << newtransaction[a].date << " $" << newtransaction[a].amount << " " << newtransaction[a].description << " " << newtransaction[a].category << endl;
		}
	}			

	if(display != 1 && display != 2)
	{
		return 0;
	}

	userfile.close();
	budgetfile.close();
	delete_info(budge,numusers);
	delete [] newtransaction;
		


return 0;
}



