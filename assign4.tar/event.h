/***************************************************************
 * Author : Gretel Rajamoney
 * Program : event.h
 * Date : 2/29/2020
 * Description : carries all of the event variables and functions
 * Input : none
 * Output : none
 * ************************************************************/

#ifndef EVENT_H
#define EVENT_H
#include <iostream>

using namespace std;
	

class Event
{
	protected:
		int spotx;
		int spoty;
		string hint;
		char symbol;
	public:
		Event();
		virtual string gethint();
		virtual void printhint();
};

#endif
