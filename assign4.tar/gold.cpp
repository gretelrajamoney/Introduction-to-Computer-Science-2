/**************************************************************
 * Author : Gretel Rajamoney
 * Program : gold.cpp
 * Date : 2/29/2020
 * Description : prints out the gold hint
 * Input : none
 * Output : gold hint
 * ***********************************************************/

#include "gold.h"


Gold::Gold()
{
	hint = "*you see a glimmer nearby*";
	symbol = 'g';
}

string Gold::gethint()
{
	return hint;
}

